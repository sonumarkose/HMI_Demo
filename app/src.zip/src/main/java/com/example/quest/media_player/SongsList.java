package com.example.quest.media_player;


import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by quest on 22/2/17.
 */
public class SongsList extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>, mClickListener{

    ArrayList songList = new ArrayList();
    ListView songView;
    Context context;
    RecyclerView recyclerView;
    SongListAdapter recycleAdapter;
    int tappedIndex;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.songslist,container,false);

        recyclerView = (RecyclerView) view.findViewById(R.id.playList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        context = container.getContext();
        if (isReadPhoneStateAllowed()) {
            startActivity();

        } else {
            requestPhoneStatePermission();
        }
        recyclerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        return view;
    }

    public void startActivity()
    {
        getLoaderManager().initLoader(1, null, this);
        //ringProgressDialog = ProgressDialog.show(context, "Please wait ...", "Downloading Contact ...", true);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        if (requestCode == 1) {

            //If permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(getActivity().getApplicationContext(), "Permission Granted", Toast.LENGTH_SHORT).show();
                startActivity();
            } else {
                //Displaying another toast if permission is not granted

            }
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri musicUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        CursorLoader cursorLoader = new CursorLoader(getActivity().getApplicationContext(), musicUri, null, null, null, android.provider.MediaStore.Audio.Media.TITLE);
        return cursorLoader;
    }


    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

        data.moveToFirst();
        recycleAdapter = new SongListAdapter(getActivity(),data);
        recyclerView.setAdapter(recycleAdapter);
        recycleAdapter.setClickListener(this);

    }
    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    private boolean isReadPhoneStateAllowed() {
        //Getting the permission status
        int result = ContextCompat.checkSelfPermission(getActivity().getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE);

        //If permission is granted returning true
        if (result == PackageManager.PERMISSION_GRANTED)
            return true;

        //If permission is not granted returning false
        return false;
    }

    private void requestPhoneStatePermission() {
        //And finally ask for the permission
        this.requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);

    }


    @Override
    public void onClick(View view, int position, Object object) {

        tappedIndex =  position;
        //playSong(position);
        FragmentManager fm = getFragmentManager();
        MediaFragment media = new MediaFragment();
        Bundle bundle = new Bundle();
        Song song = (Song) object;
        bundle.putInt("index", tappedIndex);
        ArrayList details = new ArrayList();
        details.add(song.getTitle());
        details.add(song.getArtist());
        details.add(song.getSongpath());
        details.add(song.getAlbumpath());
        bundle.putStringArrayList("songDetails",details);
        media.setArguments(bundle);
        if (fm != null) {
            FragmentTransaction ft = fm.beginTransaction();
            ft.replace(R.id.framelayout, media);
            ft.commit();
        }

    }
}
