package com.example.quest.media_player;

/**
 * Created by quest on 16/2/17.
 */
public class Song {
    private long id;
    private String title;
    private String artist;
    private String albumPath;
    private String songPath;

    public Song(long songID, String songTitle, String songArtist, String path, String songpath) {
        id=songID;
        title=songTitle;
        artist=songArtist;
        albumPath = path;
        songPath = songpath;
    }
    public long getID(){return id;}
    public String getTitle(){return title;}
    public String getArtist(){return artist;}
    public String getAlbumpath(){return albumPath;}
    public String getSongpath(){return songPath;}
}
