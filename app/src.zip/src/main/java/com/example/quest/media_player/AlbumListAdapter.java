package com.example.quest.media_player;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by quest on 24/2/17.
 */
public class AlbumListAdapter extends  RecyclerView.Adapter<AlbumListAdapter.ContactHolder>
{

    Cursor cursor;
    Context mContext;
    mClickListener clickListener;
    int positionValue,albumPositionvalue;
    ArrayList albumList = new ArrayList();

    public AlbumListAdapter(Context context, Cursor cursor) {
        mContext = context;
        this.cursor = cursor;
        positionValue = 0;
        albumPositionvalue = 0;
    }

    @Override
    public ContactHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.songlist_adapter, parent,false);
        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        view.setLayoutParams(lp);
        return new ContactHolder(view);
    }


    @Override
    public int getItemCount() {
        return cursor.getCount();
    }


    public void setClickListener(mClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }
    @Override
    public void onBindViewHolder(ContactHolder holder, int position) {
        cursor.moveToPosition(position);
        holder.songTitle.setText(cursor.getString(cursor.getColumnIndex
                (MediaStore.Audio.Albums.ALBUM)));
        holder.songArtist.setText(cursor.getString(cursor.getColumnIndex
                (MediaStore.Audio.Albums.ARTIST)));// get string for album art.
        holder.songDuration.setText(cursor.getString(cursor.getColumnIndex
                (MediaStore.Audio.Albums.NUMBER_OF_SONGS))+" Song");
        String albumUri = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.ALBUM_ART));


        if (albumUri != null) {
            holder.albumArt.setImageURI(Uri.parse(albumUri));
        } else {
            holder.albumArt.setImageResource(R.drawable.headphone);
        }
        if(albumPositionvalue<=position)
        {
            albumList.add(position,getDetailsByPosition(position));
            albumPositionvalue++;
        }

    }

    class ContactHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        ImageView albumArt;
        TextView songTitle, songArtist, songDuration;

        public ContactHolder(View itemView) {
            super(itemView);
            albumArt = (ImageView) itemView.findViewById(R.id.albumart);
            songTitle = (TextView) itemView.findViewById(R.id.songtitle);
            songArtist = (TextView) itemView.findViewById(R.id.songtrack);
            songDuration = (TextView) itemView.findViewById(R.id.songDuration);
            itemView.setClickable(true);
            itemView.setOnClickListener(this);

        }
        /**
         * Called when a view has been clicked.
         *
         * @param v The view that was clicked.
         */
        @Override
        public void onClick(View v) {
            if (clickListener != null) clickListener.onClick(v, getAdapterPosition(),albumList.get(getAdapterPosition()));

        }
    }

    public Album getDetailsByPosition(int pos)
    {
        cursor.moveToPosition(pos);
        Long id = cursor.getLong(cursor.getColumnIndex
                (MediaStore.Audio.Albums._ID));
        String title = cursor.getString(cursor.getColumnIndex
                (MediaStore.Audio.Albums.ALBUM));
        String artist = cursor.getString(cursor.getColumnIndex
                (MediaStore.Audio.Albums.ARTIST));
        /*String albumid = cursor.getString(cursor.getColumnIndex
                (android.provider.MediaStore.Audio.Albums.ALBUM_ID));*/
        String songPath = "";
        String albumUri = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.ALBUM_ART));
        return new Album(id,title,artist,albumUri,songPath);

    }
}
