package com.example.quest.media_player;

import android.view.View;

/**
 * Created by quest on 27/2/17.
 */
public interface mClickListener {
    void onClick(View view, int position, Object o);
}
