package com.example.quest.media_player;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by quest on 1/3/17.
 */
public class AlbumSongAdapter extends  RecyclerView.Adapter<AlbumSongAdapter.ContactHolder> {
    Cursor cursor;
    Context mContext;
    mClickListener clickListener;
    int positionValue,albumPositionvalue;
    ArrayList albumList = new ArrayList();
    ArrayList songList = new ArrayList();
    private Utilities utils;

    public AlbumSongAdapter(Context context, ArrayList list) {
        mContext = context;
        songList = list;
        positionValue = 0;
        albumPositionvalue = 0;
        utils = new Utilities();
    }

    @Override
    public ContactHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.albumsonglist_adapter, parent,false);
        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        view.setLayoutParams(lp);
        return new ContactHolder(view);
    }


    @Override
    public int getItemCount() {
        return songList.size();
    }


    public void setClickListener(mClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }
    @Override
    public void onBindViewHolder(ContactHolder holder, int position) {

        AlbumSong albumSong  =(AlbumSong)  songList.get(position);
        String title = albumSong.getTitle();
        String artist = albumSong.getArtist();
        String duration = albumSong.getDuration();
        String albumUri = albumSong.getAlbumpath();
        holder.songTitle.setText(title);
        holder.songArtist.setText(artist);
        holder.songDuration.setText(duration);
        if (albumUri != null) {
            holder.albumArt.setImageURI(Uri.parse(albumUri));
        } else {
            holder.albumArt.setImageResource(R.drawable.headphone);
        }

        /*cursor.moveToPosition(position);
        holder.songTitle.setText(cursor.getString(cursor.getColumnIndex
                (MediaStore.Audio.Albums.ALBUM)));
        holder.songArtist.setText(cursor.getString(cursor.getColumnIndex
                (MediaStore.Audio.Albums.ARTIST)));// get string for album art.
        holder.songDuration.setText(cursor.getString(cursor.getColumnIndex
                (MediaStore.Audio.Albums.NUMBER_OF_SONGS)));
        String albumUri = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.ALBUM_ART));


        if (albumUri != null) {
            holder.albumArt.setImageURI(Uri.parse(albumUri));
        } else {
            holder.albumArt.setImageResource(R.drawable.headphone);
        }
        if(albumPositionvalue<=position)
        {
            albumList.add(position,getDetailsByPosition(position));
            albumPositionvalue++;
            System.out.println("AlbumListAdapter.onBindViewHolder()->Position =" + position + "AlbumList size =" + albumList.size());
        }*/

    }

    class ContactHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        ImageView albumArt;
        TextView songTitle, songArtist, songDuration;

        public ContactHolder(View itemView) {
            super(itemView);
            albumArt = (ImageView) itemView.findViewById(R.id.albumart);
            songTitle = (TextView) itemView.findViewById(R.id.songtitle);
            songArtist = (TextView) itemView.findViewById(R.id.songtrack);
            songDuration = (TextView) itemView.findViewById(R.id.songDuration);
            itemView.setClickable(true);
            itemView.setOnClickListener(this);

        }
        /**
         * Called when a view has been clicked.
         *
         * @param v The view that was clicked.
         */
        @Override
        public void onClick(View v) {
           // if (clickListener != null) clickListener.onClick(v, getAdapterPosition(),songList.get(getAdapterPosition()));

            Bundle bundle = new Bundle();
            AlbumSong albumSong = (AlbumSong) songList.get(getAdapterPosition());
            MediaFragment media = new MediaFragment();
            FragmentManager fm = ((AppCompatActivity)mContext).getSupportFragmentManager();
            bundle.putInt("index", getAdapterPosition());
            ArrayList details = new ArrayList();
            details.add(albumSong.getTitle());
            details.add(albumSong.getArtist());
            details.add(albumSong.getSongPath());
            details.add(albumSong.getAlbumpath());
            bundle.putStringArrayList("songDetails",details);
            media.setArguments(bundle);
            if (fm != null) {
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.framelayout, media);
                ft.commit();
            }
        }
    }

   /* public Album getDetailsByPosition(int pos)
    {
        cursor.moveToPosition(pos);
        Long id = cursor.getLong(cursor.getColumnIndex
                (MediaStore.Audio.Albums._ID));
        String title = cursor.getString(cursor.getColumnIndex
                (MediaStore.Audio.Albums.ALBUM));
        String artist = cursor.getString(cursor.getColumnIndex
                (MediaStore.Audio.Albums.ARTIST));
        *//*String albumid = cursor.getString(cursor.getColumnIndex
                (android.provider.MediaStore.Audio.Albums.ALBUM_ID));*//*
        String songPath = "";
        String albumUri = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.ALBUM_ART));
        return new Album(id,title,artist,albumUri,songPath);

    }*/
}
