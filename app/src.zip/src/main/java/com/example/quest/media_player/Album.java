package com.example.quest.media_player;

/**
 * Created by quest on 16/2/17.
 */
public class Album {
    private long id;
    private String title;
    private String artist;
    private String albumPath;
    private String album_id;

    public Album(long songID, String songTitle, String songArtist, String path, String albumid) {
        id=songID;
        title=songTitle;
        artist=songArtist;
        albumPath = path;
        album_id = albumid;
    }
    public long getID(){return id;}
    public String getTitle(){return title;}
    public String getArtist(){return artist;}
    public String getAlbumpath(){return albumPath;}
    public String getSongPath(){return album_id;}
}
