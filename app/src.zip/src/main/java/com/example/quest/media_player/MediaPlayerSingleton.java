package com.example.quest.media_player;

import android.media.MediaPlayer;

import java.util.ArrayList;

/**
 * Created by quest on 28/2/17.
 */
public class MediaPlayerSingleton extends MediaPlayer{
    private static MediaPlayerSingleton mediaPlayerSingleton;
    private ArrayList SongList;
    private MediaPlayerSingleton() {
        SongList = new ArrayList();
    }

    public static MediaPlayerSingleton getInstance() {
        //synchronized (mediaPlayerSingleton)  { // if you'll be using it in moe then one thread
            if(mediaPlayerSingleton == null)
                mediaPlayerSingleton = new MediaPlayerSingleton();
        //}

        return mediaPlayerSingleton;
    }

    public ArrayList getSongList() {
        return SongList;
    }

    public void setSongList(ArrayList songList) {
        SongList = songList;
    }
}